#include "test.h"

int	main(int ac, char **av)
{
    if (ac > 1)
	    ft_printf("%s\n", av[1]);
}
