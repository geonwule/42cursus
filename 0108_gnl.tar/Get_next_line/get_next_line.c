/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: geonwule <geonwule@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/29 19:35:49 by geonwule          #+#    #+#             */
/*   Updated: 2023/01/08 15:35:41 by geonwule         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

void	*ft_memset(void *dest, int value, size_t count)
{
	size_t			i;
	unsigned char	*temp;

	temp = (unsigned char *)dest;
	i = 0;
	while (i < count)
	{
		temp[i] = (unsigned char)value;
		i++;
	}
	return (dest);
}

void	free_linked(t_list *origin)
{
	t_list *temp;

	while (origin)
	{
		temp = origin;
		origin = origin->next;
		free(temp);
	}
}

char	*ret_out(char *back, t_list *origin)
{
	char			*ret;
	static int		i;
	int	last_i;
	int j = i;

	if (i >= (int)ft_strlen(back))
		return (0);
	while (back[i] == '\n' && back[i] != '\0')
		i++;
	while (back[i] != '\n' && back[i] != '\0')
		i++;
	last_i = i;
	ret = (char *)malloc(sizeof(char) * (i - j + 1));
	if (ret == NULL)
		return (0);
	ret[i - j] = '\0';
	i--;
	while (i - j >= 0)
	{
		ret[i - j] = back[i];
		i--;
	}
	i = last_i;
	free_linked(origin);
	return (ret);
}

void	linked_set(t_list *origin, int fd, int *readsize)
{
	char	buf[BUFFER_SIZE + 1];

	ft_memset(buf, 0, BUFFER_SIZE + 1);	// buf clear
	while (1)
	{
		*readsize = read(fd, buf, BUFFER_SIZE);
		if (*readsize == -1)
			return ;// (0);	//error
		if (*readsize == 0)
			break ;	//EOF
		buf[BUFFER_SIZE] = '\0';
		ft_lstadd_back(&origin, ft_lstnew(ft_strdup(buf)));
		ft_memset(buf, 0, BUFFER_SIZE + 1);	// buf clear for while
		if (*readsize < BUFFER_SIZE)
			break ;
	}
}

char	*get_next_line(int fd)
{
	t_list			*origin;
	static char		*back;
	int				readsize;

	origin = ft_lstnew(NULL);
	readsize = 0;
	if (!back)	// first back set up
	{
		linked_set(origin, fd, &readsize);
		t_list	*temp;

		temp = origin;
		origin = origin->next;
		free(temp);
		if (origin == NULL)
			return (0);
		if (readsize != 0)
		{
			back = origin->content;
			origin = origin->next;
			while (origin)
			{
				back = ft_strjoin(back, origin->content);
				origin = origin->next;
			}
		}
	}
	return (ret_out(back, origin));
}

/*
char	*get_next_line(int fd)
{
	char	backup[100000];
	char	buf;
	char	*str;
	int		i;
	int		read_size;
	i = 0;
	while (1)
	{
		read_size = read(fd, &buf, 1);
		if (read_size < 0 || (read_size == 0 && buf == '\0'))
			return (0);
		if (read_size == 0)
			break ;
		backup[i] = buf;
		i++;
		if (buf == '\n')
			break ;
	}
	backup[i] = '\0';
	str = (char *)malloc(sizeof(char) * (i + 1));
	while (i >= 0)
	{
		str[i] = backup[i];
		i--;
	}
	return (str);
}*/
