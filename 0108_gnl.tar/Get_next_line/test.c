#include <stdio.h>
#include <stdlib.h>

int	main()
{
	char	*s;
	char	s1[6] = "ABCDE";
	char	s2[6] = "12345";
	int	i[2];

	s = malloc(11);
	i[0] = -1;
	i[1] = -1;

	while (++i[0] < 5)
	{
		s[i[0]] = s1[i[0]];
	}
	while (++i[1] < 5)
	{
		s[i[0] + i[1]] = s2[i[1]];
	}
	s[i[0] + i[1]] = '\0';
	printf("s1 = %s\n", s1);
	printf("s2 = %s\n", s2);
	for (int j = 0; j < 10; j++)
	{
		printf("s[%d] = %c\n", j, s[j]);
	}
	printf("%s\n", s);
	free (s);
}
